public class Demo
{
  public static void main(String[] args)
  {
    BinarySearchTree BST = new BinarySearchTree();
    BST.loadSampleData();

    BST.insert(2);
    BST.insert(9);
    BST.print();

    System.out.println("");
//    System.out.println(BST.findMin());
//    System.out.println(BST.findMax());]
    System.out.println(BST.find(2).getElement());

  }
}
