public class BinarySearchTree extends BinaryTree
{
  public BinarySearchTree()
  {
  }
  public void loadSampleData(){
  //create nodes
  var root = new BinaryTreeNode(5);

  var treeNode3 = new BinaryTreeNode(3);
  var treeNode1 = new BinaryTreeNode(1);
  var treeNode7 = new BinaryTreeNode(7);
  var treeNode8 = new BinaryTreeNode(8);

  //add the nodes to the tree
  root.addLeftChild(treeNode1);
  root.addRightChild(treeNode7);

  treeNode1.addRightChild(treeNode3);

  treeNode7.addRightChild(treeNode8);

  this.setRoot(root);
}

  public void insert(int elementToInsert){
    insertToNode(elementToInsert, this.getRoot());
  }

  private void insertToNode(int elementToInsert, BinaryTreeNode treeNode){
    //case: element to insert is smaller than the current node
    if(elementToInsert < treeNode.getElement()){
      //case: left node is empty > just add it
      if(treeNode.getLeftChild() == null){
        treeNode.addLeftChild(new BinaryTreeNode(elementToInsert));
      }
      //case: left node is not empty > start the process again
      else{
        insertToNode(elementToInsert, treeNode.getLeftChild());
      }
    }
    //case: element to insert is bigger than the current node
    else if(elementToInsert > treeNode.getElement()){
      //case: right node is empty > just add it
      if(treeNode.getRightChild() == null){
        treeNode.addRightChild(new BinaryTreeNode(elementToInsert));
      }
      //case: right node is not empty > start the process again
      else{
        insertToNode(elementToInsert, treeNode.getRightChild());
      }
    }
    //case: element to insert has the same value than the current node
    else{
      //don't do anything, error could also be thrown here
    }
  }

  public int findMin(){
    int currentSmallest = getRoot().getElement();
    return findMinFrom(currentSmallest, getRoot());
  }

  private int findMinFrom(int currentSmallest, BinaryTreeNode treeNode){
    if(currentSmallest > treeNode.getElement())
      currentSmallest = treeNode.getElement();

    if(treeNode.getLeftChild() == null)
      return currentSmallest;

    return findMinFrom(currentSmallest, treeNode.getLeftChild());
  }

  public int findMax(){
    int currentLargest = getRoot().getElement();
    return findMaxFrom(currentLargest, getRoot());
  }

  private int findMaxFrom(int currentLargest, BinaryTreeNode treeNode){
    if(currentLargest < treeNode.getElement())
      currentLargest = treeNode.getElement();

    if(treeNode.getRightChild() == null)
      return currentLargest;

    return findMaxFrom(currentLargest, treeNode.getRightChild());
  }

  public void removeElement(int element){
    //first we need to finds the node by descending the tree from the root
    BinaryTreeNode nodeToDelete= find(element, getRoot());

    //if the node does not exist, exit the function
    if(nodeToDelete == null)
      return;

    //case: it's an internal node
    if(nodeToDelete.getLeftChild() != null && nodeToDelete.getRightChild() != null){
      //the some hard shit here
    }

    //case: it's a half leaf with right node, just replace it
    if (nodeToDelete.getRightChild() != null){

    }


    //case: it's a leaf, the node can be deleted without modifying the tree


  }

  public BinaryTreeNode find(int elementToFind){
    return find(elementToFind, getRoot());
  }

  private BinaryTreeNode find(int elementToFind, BinaryTreeNode treeNode){
    //case: the current node is a the elementToFind we were looking for
    if(treeNode.getElement() == elementToFind)
      return treeNode;

    //case: the current node is smaller than the element we are looking for, lets continue looking on the right side
    if(elementToFind > treeNode.getElement()){
      if(treeNode.getRightChild() != null)
        return find(elementToFind, treeNode.getRightChild());
      else return null;
    }

    //case: the current node is bigger than the elements we are looking for, lets continue looking on the right side.
    if(treeNode.getLeftChild() == null)
      return null;
    return find(elementToFind, treeNode.getLeftChild());
  }

  public void rebalance(){
  }

  public void print(){
    new BinaryTreePrint().printTree(this.getRoot());
  }
}
