import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BinarySearchTreeTest
{
     private BinarySearchTree binarySearchTree;

     @BeforeEach
     public void createTree()
     {
          binarySearchTree = new BinarySearchTree();
     }

     @Test
     public void addElementToTree() {

     }
}